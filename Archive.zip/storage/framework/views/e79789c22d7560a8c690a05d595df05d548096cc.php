<body>

<header class="header-basic-light">

	<div class="header-limiter">

		<h1><a href="#">Company<span>logo</span></a></h1>

		<nav>
			<a href="#" class="selected">Internal</a>
			<a href="#">Jadwal Ruangan</a>
			<a href="#">Eselon & Kapus</a>
		</nav>
	</div>

</header>
