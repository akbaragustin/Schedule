<?php if(!empty (\Session::get('messageError'))): ?>
<script type="text/javascript">

 swal("<?php echo e(\Session::get('messageError')); ?>")

</script>

<?php endif; ?>
<?php if(!empty (\Session::get('insertError'))): ?>
<script type="text/javascript">

 swal("<?php echo e(\Session::get('insertError')); ?>",'Isi Semua Data!')

</script>

<?php endif; ?>
<?php if(!empty (\Session::get('insertSuccess'))): ?>
<script type="text/javascript">

 swal("<?php echo e(\Session::get('insertSuccess')); ?>", "You clicked the button!", "success")

</script>

<?php endif; ?>

<?php if(!empty(\Session::get('insertFailsInfantUndang'))): ?>
<script type="text/javascript">
 swal("Gagal Menyimpan","Nama Infant dan Nama pejabat yang di undang sama !")
</script>
<?php endif; ?>
<?php if(!empty(\Session::get('insertFailsdate'))): ?>
<script type="text/javascript">
 swal("Gagal Menyimpan","waktu mulai lebih besar dari waktu akhir !")
</script>
<?php endif; ?>
<?php if(!empty(\Session::get('insertFailsRuangan'))): ?>
<script type="text/javascript">
 swal("Gagal Menyimpan","Ruangan yang anda gunakan sudah terisi")
</script>
<?php endif; ?>
